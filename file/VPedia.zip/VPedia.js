
/*

    #Rerezz Official 
    #Barmods Official 
*/

require('./settings');

const {
  proto,
  getContentType,
  prepareWAMessageMedia,
  makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeInMemoryStore,
  generateWAMessageContent,
  jidDecode,
  relayWAMessage,
  getAggregateVotesInPollMessage,
  downloadContentFromMessage,
  fetchLatestWaWebVersion,
  makeCacheableSignalKeyStore,
  Browsers,
  generateForwardMessageContent,
  MessageRetryMap,
  baileys,
  generateWAMessageFromContent,
  InteractiveMessage
} = require("@whiskeysockets/baileys");


const fs = require('fs');
const axios = require('axios');
const chalk = require("chalk");
const util = require("util");
const archiver = require('archiver');
const moment = require("moment-timezone");

const loadDatabase = () => {
  const defaultData = {
    users: {}
  }
  try {
    const dbFile = './database/database.json';

    if (fs.existsSync(dbFile)) {
      const rawData = fs.readFileSync(dbFile, 'utf-8');
      const parsedData = JSON.parse(rawData);

      global.db = global.db || {};
      global.db.data = { ...defaultData, ...parsedData };
    } else {
      global.db = global.db || {}; 
      global.db.data = defaultData;
      fs.writeFileSync(dbFile, JSON.stringify(defaultData, null, 2));
    }
  } catch (err) {
    console.error('Database load error:', err);
    global.db = global.db || {};
    global.db.data = defaultData;
  }
}

loadDatabase();
const saveDatabase = () => {
    try {
        fs.writeFileSync('./database/database.json', JSON.stringify(global.db.data, null, 2))
    } catch (err) {
        console.error('Database save error:', err)
    }
}
setInterval(saveDatabase, 30000)

moment.tz.setDefault("Asia/Jakarta").locale("id")


module.exports = VPedia = async (VPedia, m, chatUpdate, store) => {

try {
const initializeUser = (sender) => {
  if (!global.db.data.users[sender]) {
    global.db.data.users[sender] = {
      saldo: 0,
      trxid: null,
      statusdepo: false,
      premium: false,
      premiumExpired: null
    }
  }
  const user = global.db.data.users[sender];
}

initializeUser(m.sender)

const addPremium = (sender, days = 30) => {
  const now = Date.now();
  const expire = now + days * 24 * 60 * 60 * 1000; 
  if (!global.db.data.users[sender]) initializeUser(sender);
  global.db.data.users[sender].premium = true;
  global.db.data.users[sender].premiumExpired = expire;
  if (typeof saveDatabase === 'function') saveDatabase();
};
const checkPremiumStatus = (sender) => {
  const user = global.db.data.users[sender];
  if (!user || !user.premium) return false;
  
  const now = Date.now();
  if (user.premiumExpired && now > user.premiumExpired) {
    user.premium = false;
    user.premiumExpired = null;
    if (typeof saveDatabase === 'function') saveDatabase();
    return false;
  }
  return true;
};
function parseDuration(str) {
  const match = str.match(/^(\d+)([mhd])$/i);
  if (!match) return null;

  const num = parseInt(match[1]);
  const unit = match[2].toLowerCase();

  switch (unit) {
    case 'm': return num * 60 * 1000;           // menit ke ms
    case 'h': return num * 60 * 60 * 1000;      // jam ke ms
    case 'd': return num * 24 * 60 * 60 * 1000; // hari ke ms
    default: return null;
  }
}

const checkAllPremiumExpired = async () => {
  const now = Date.now();
  for (const sender in global.db.data.users) {
    const user = global.db.data.users[sender];
    if (user.premium && user.premiumExpired && now > user.premiumExpired) {
      user.premium = false;
      user.premiumExpired = null;
      if (typeof saveDatabase === 'function') saveDatabase();

      try {
        await VPedia.sendMessage(sender, {
          text: '⚠️ Status premium kamu sudah habis. Silakan perpanjang untuk menikmati fitur premium lagi.'
        });
      } catch (e) {
        console.error('Gagal kirim pesan premium habis ke', sender, e);
      }
    }
  }
};

setInterval(checkAllPremiumExpired, 1000);


    const body = (
      m.mtype === "conversation" ? m.message.conversation :
      m.mtype === "imageMessage" ? m.message.imageMessage.caption :
      m.mtype === "videoMessage" ? m.message.videoMessage.caption :
      m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
      m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
      m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
      m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
      m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
      m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text :
      ""
    );

    const sender = m.key.fromMe
      ? VPedia.user.id.split(":")[0] || VPedia.user.id
      : m.key.participant || m.key.remoteJid;
    const senderNumber = sender.split('@')[0];
    const budy = (typeof m.text === 'string' ? m.text : '');
    const prefa = ["."]; 
    const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) 
      ? body.match(/^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/gi)[0] 
      : '/';
    const isCommand = body.startsWith(prefix);
    const from = m.key.remoteJid;
    const isGroup = from.endsWith("@g.us");

    const botNumber = await VPedia.decodeJid(VPedia.user.id);
    const isCreator = global.owner .map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender);
    const isBot = botNumber.includes(senderNumber);

    const args = body.trim().split(/ +/).slice(1);
    const pushname = m.pushName || "No Name";
    const text = args.join(" ");
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    const qmsg = (quoted.msg || quoted);
    const isMedia = /image|video|sticker|audio/.test(mime);
    const isPc = from.endsWith('@s.whatsapp.net');
    const isPrem = checkPremiumStatus(m.sender);
    const groupMetadata = isGroup ? await VPedia.groupMetadata(m.chat).catch(() => {}) : '';
    const groupOwner = isGroup && groupMetadata ? groupMetadata.owner : '';
    const groupName = isGroup ? groupMetadata.subject : '';
    const participants = isGroup ? groupMetadata.participants : [];
    const groupAdmins = isGroup ? participants.filter(v => v.admin !== null).map(v => v.id) : [];
    const isGroupAdmins = isGroup ? groupAdmins.includes(sender) : false;
    const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
    const isAdmins = isGroup ? groupAdmins.includes(sender) : false;

    moment.locale('id');
    const tanggal = moment.tz('Asia/Jakarta').format('DD/MM/YY');
    const hariini = moment.tz('Asia/Makassar').format('dddd, DD MMMM YYYY');
    const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss');

    let ucapanWaktu = 'Selamat Malam';
    if (time2 < "03:00:00") ucapanWaktu = 'Selamat Tengah Malam';
    else if (time2 < "05:00:00") ucapanWaktu = 'Selamat Subuh';
    else if (time2 < "10:00:00") ucapanWaktu = 'Selamat Pagi';
    else if (time2 < "15:00:00") ucapanWaktu = 'Selamat Siang';
    else if (time2 < "18:00:00") ucapanWaktu = 'Selamat Sore';
    else if (time2 < "19:00:00") ucapanWaktu = 'Selamat Petang';
    if (m.message && isCommand) {
      console.log(chalk.red('--------------------'));
      console.log(chalk.red(`➤ New Messages`));
      console.log(chalk.red(
        ` ╭─ > Tanggal WITA: ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Makassar' })} \n` +
        ` ├─ > Tanggal WIB: ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })} \n` +
        ` ├─ > Pesan: ${m.body || m.mtype} \n` +
        ` ├─ > Pengirim: ${pushname} \n` +
        ` ╰─ > JID: ${senderNumber}`
      ));
      if (m.isGroup) {
        console.log(chalk.red(
          ` ╭─ > Grup: ${groupName} \n` +
          ` ╰─ > GroupJid: ${m.chat}`
        ));
      }
      console.log();
    }

    const command = isCommand ? body.slice(prefix.length).trim().split(/ +/).shift().toLowerCase() : '';
    
    switch (command) {
      //=====[ AWAL FEATURE CASE ]=====//
case "menu": {
  const menuText = `✨ *MENU BOT ${botname}* ✨

Halo, *${m.pushName}* 👋
Selamat datang! Berikut daftar menu bot yang bisa kamu gunakan:

┏━━━═┅ Owner Menu ┅═━━━┓
┃ ⌨️ *${prefix}addprem* 
┃ ⌨️ *${prefix}listprem*
┃ ⌨️ *${prefix}delprem* 
┃ ⌨️ *${prefix}profile* 
┃ ⌨️ *${prefix}backup*  
┃ ⌨️ *${prefix}restdb*  
┗━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━━═┅ Topup Menu ┅═━━━┓
┃ ⌨️ *${prefix}category*
┃ ⌨️ *${prefix}provider*
┃ ⌨️ *${prefix}deposit* 
┃ ⌨️ *${prefix}order*   
┃ ⌨️ *${prefix}saldo*   
┃ ⌨️ *${prefix}cpanel*  
┃ ⌨️ *${prefix}buypanel*
┗━━━━━━━━━━━━━━━━━━━━━━━┛

Semoga harimu menyenangkan! 🌟`;

  const buttons = [
    { buttonId: `${prefix}deposit`, buttonText: { displayText: "📖 Bantuan" }, type: 1 },
    { buttonId: `${prefix}owner`, buttonText: { displayText: "👤 Owner" }, type: 1 },
  ];

  await VPedia.sendMessage(m.chat, {
    image: { url: imgpedia },
    caption: menuText,
    footer: `© ${botname}`,
    buttons: buttons,
    headerType: 4
  }, { quoted: m });
}
break

case 'owner': {
const teks = `Haai ${m.pushName} Ini adalah kontak owner ku.
Harap jangan spam atau telfon!`
  try {
    let msgii = generateWAMessageFromContent(
      m.chat,
      {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2
            },
            interactiveMessage: proto.Message.InteractiveMessage.create({
              contextInfo: { mentionedJid: [m.sender] },
              body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons: [
                  {
                    "name": "cta_url",
                    "buttonParamsJson": JSON.stringify({
                      "display_text": "Owner",
                      "url": `https://wa.me/${ownernumber}`,
                      "merchant_url": `https://wa.me/${ownernumber}`
                    })
                  }
                ]
              })
            })
          }
        }
      },
      { userJid: m.chat, quoted: m }
    );
    await VPedia.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id });
  } catch (e) {
    console.error(e);
    m.reply('❌ Terjadi kesalahan saat mengirim pesan tombol link.');
  }
}
break;



case 'addprem': {
  if (!isCreator) return m.reply('❌ Fitur ini hanya untuk owner.');
  if (!text) return m.reply(`Format salah!\nContoh: ${prefix}addprem 6281234567890 1d`);
  let [nomorRaw, durasiRaw] = text.split(' ');
  if (!nomorRaw || !durasiRaw) return m.reply(`Format salah!\nContoh: ${prefix}addprem 6281234567890 1d`);
  const durMs = parseDuration(durasiRaw);
  if (!durMs) return m.reply('Format durasi salah! Gunakan format 1m (menit), 1h (jam), 1d (hari)');
  const senderPremium = nomorRaw.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  if (!global.db.data.users[senderPremium]) initializeUser(senderPremium);
  const now = Date.now();
  const expire = now + durMs;
  global.db.data.users[senderPremium].premium = true;
  global.db.data.users[senderPremium].premiumExpired = expire;
  if (typeof saveDatabase === 'function') saveDatabase();
  const expireDate = new Date(expire).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
  await m.reply(`✅ Berhasil menambahkan premium kepada:\nNomor: ${nomorRaw}\nDurasi: ${durasiRaw}\nBerakhir pada: ${expireDate}`);
  try {
    await VPedia.sendMessage(senderPremium, {
      text: `🎉 Selamat! Kamu mendapatkan status Premium selama ${durasiRaw} mulai sekarang sampai ${expireDate}. Nikmati fitur premium ya!`
    });
  } catch (e) {
    console.error(`Gagal mengirim pesan premium ke ${senderPremium}:`, e);
  }
}
break

case 'listprem': {
  if (!isCreator) return m.reply('❌ Fitur ini hanya untuk owner.');
  const users = global.db.data.users;
  const premUsers = Object.entries(users)
    .filter(([_, user]) => user.premium && user.premiumExpired)
    .map(([jid, user]) => {
      const expireDate = new Date(user.premiumExpired);
      return `- Nomor: ${jid.replace('@s.whatsapp.net', '')}\n  Berlaku sampai: ${expireDate.toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}`;
    });
  if (premUsers.length === 0) {
    return m.reply('❌ Tidak ada user premium saat ini.');
  }
  const listMessage = `📋 *Daftar User Premium:*\n\n${premUsers.join('\n\n')}`;
  await m.reply(listMessage);
}
break

case 'delprem': {
  if (!isCreator) return m.reply('❌ Fitur ini hanya untuk owner.');
  if (!text) return m.reply(`❗️ Format salah!\nContoh: ${prefix}delprem 6281234567890`);
  const nomor = text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  if (!global.db.data.users[nomor] || !global.db.data.users[nomor].premium) {
    return m.reply('❌ User tersebut tidak memiliki status premium.');
  }
  global.db.data.users[nomor].premium = false;
  global.db.data.users[nomor].premiumExpired = null;
  if (typeof saveDatabase === 'function') saveDatabase();
  await m.reply(`✅ Premium user dengan nomor ${nomor.replace('@s.whatsapp.net', '')} berhasil dihapus.`);
  try {
    await VPedia.sendMessage(nomor, {
      text: '⚠️ Status premium kamu telah dicabut oleh owner.'
    });
  } catch (e) {
    console.error('Gagal mengirim pesan ke user yang dihapus premium:', e);
  }
}
break;


case "profile": {
  if (!isCreator) return m.reply("`Fitur ini hanya untuk owner`");
  try {
    const URL = `${BASE_URL}/h2h/profile?apikey=${API_KEY}`;
    const response = await axios.get(URL);
    if (response.data.success) {
      const profile = response.data.data;
      let latestHistoryText = "Tidak ada riwayat aktivitas.";
      if (profile.history && profile.history.length) {
        profile.history.sort((a, b) => new Date(b.tanggal) - new Date(a.tanggal));
        const h = profile.history[0];
        latestHistoryText =
          `• Aktivitas: ${h.aktivitas}\n` +
          `  Nominal: ${h.nominal}\n` +
          `  Status: ${h.status}\n` +
          (h.code ? `  Code: ${h.code}\n` : '') +
          `  Tanggal: ${new Date(h.tanggal).toLocaleString('id-ID')}\n`;
      }
      
      const message =
`*Profil Kamu*
Nama Lengkap: ${profile.fullname}
Username: ${profile.username}
Nomor: ${profile.nomor}
Email: ${profile.email}
Saldo: ${profile.saldo}
Coin: ${profile.coin}
Role: ${profile.role}
Verified: ${profile.isVerified ? "✅" : "❌"}
Tanggal Daftar: ${new Date(profile.tanggalDaftar).toLocaleDateString('id-ID')}
Last Login: ${new Date(profile.lastLogin).toLocaleString('id-ID')}
Referral Code: ${profile.referralCode}

*Riwayat Aktivitas Terbaru:*
${latestHistoryText}`;
      
      VPedia.sendMessage(m.chat, {
        image: { url: profile.profileUrl },
        caption: message,
      }, { quoted: m });
    } else {
      await m.reply(`Gagal mengambil data profil: ${response.data.message || 'Unknown error'}`);
    }
  } catch (error) {
    console.log('Error detail:', error.response ? error.response.data : error.message);
    await m.reply(`Error saat request profil: ${error.response?.data?.message || error.message}`);
  }
}
break

case 'backup': {
  if (!isCreator) return m.reply('❌ Fitur ini hanya untuk owner.');
  const outputZip = './VPedia.zip';
  const output = fs.createWriteStream(outputZip);
  const archive = archiver('zip', { zlib: { level: 9 }});
  output.on('close', async () => {
    try {
      await VPedia.sendMessage(m.chat, {
        document: fs.readFileSync(outputZip),
        fileName: 'VPedia.zip',
        mimetype: 'application/zip'
      }, { quoted: m });
      fs.unlinkSync(outputZip);
    } catch (e) {
      m.reply('❌ Gagal mengirim file backup.');
      console.error(e);
    }
  });
  archive.on('error', err => {
    m.reply('❌ Gagal membuat backup.');
    console.error(err);
  });
  archive.pipe(output);
  archive.glob('**/*', {
    ignore: ['node_modules/**', 'package-lock.json', 'VPedia.zip', 'sessionn']
  });

  archive.finalize();
}
break

case 'resetdb': {
  if (!isCreator) return m.reply('❌ Fitur ini hanya untuk owner.');
  try {
    global.db.data.users = {};
    if (typeof saveDatabase === 'function') saveDatabase();
    m.reply('✅ Database user berhasil di-reset, semua data telah dihapus.');
  } catch (e) {
    console.error(e);
    m.reply('⚠️ Gagal mereset database user.');
  }
}
break;


case 'category':
case 'kategori': {
    try {
        const axios = require('axios');
        const url = `${BASE_URL}/h2h/categori?apikey=${API_KEY}`;
        const res = await axios.get(url);
        const data = res.data;
        if (!data.success) {
            return m.reply('❌ Gagal mengambil data kategori.');
        }
        const categories = data.data;
        const rows = categories.map((cat, index) => (
            {
              header: '🗂️ Kategori Produk',
              title: `📌 ${cat}`,
              id: `.listcategoryy ${cat}`
            }
        ));
        const formattedList = categories.map((cat, i) => `🔹 *${i + 1}.* ${cat}`).join('\n');
        const menuButton = {
            buttonId: 'action',
            buttonText: { displayText: '📦 PILIH KATEGORI' },
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: '📦 Kategori Produk Tersedia',
                    sections: [
                        {
                            title: '🗂️ Silakan pilih kategori',
                            highlight_label: 'Tersedia',
                            rows: rows
                        }
                    ]
                }),
            },
        };
        await VPedia.sendMessage(m.chat, {
            document: { url: imgpedia },
            caption: `🎯 *LIST KATEGORI PRODUK*\n\n${formattedList}`,
            mimetype: 'application/zip',
            footer: wm,
            buttons: [
                {
                    buttonId: '.deposit',
                    buttonText: { displayText: '💶 DEPOSIT' },
                    type: 1,
                },
                menuButton
            ],
            headerType: 5,
            viewOnce: true,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                externalAdReply: {
                    title: wm,
                    body: 'V-PEDIA',
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    thumbnailUrl: imgpedia,
                    sourceUrl: saluran,
                    showAdAttribution: false,
                    containsAutoReply: true,
                    mentionedJid: [m.sender]
                },
                forwardedNewsletterMessageInfo: {
                    newsletterJid: idch,
                    newsletterName: wm,
                    serverMessageId: 143,
                },
                businessMessageForwardInfo: {
                    businessOwnerJid: VPedia.decodeJid(VPedia.user.id),
                }
            }
        });
    } catch (err) {
        console.error(err);
        m.reply('⚠️ Terjadi kesalahan saat mengambil kategori.');
    }
}
break

case 'listcategoryy': {
    try {
        const axios = require('axios');
        const [categoryRaw, pageRaw] = text.split(' ');
        const category = categoryRaw?.trim();
        const page = parseInt(pageRaw) || 1;
        if (!category) {
            return m.reply('❌ Contoh penggunaan:\n.produk PLN\n.produk PLN 2');
        }
        const url = `${BASE_URL}/h2h/price-list?category=${category}&apikey=${API_KEY}`;
        const res = await axios.get(url);
        const data = res.data;
        if (!data.success || !Array.isArray(data.data)) {
            return m.reply('❌ Gagal mengambil data produk.');
        }
        const products = data.data;
        const itemsPerPage = 5;
        const totalPages = Math.ceil(products.length / itemsPerPage);
        if (page > totalPages || page < 1) {
            return m.reply(`❌ Halaman tidak ditemukan. Total halaman: ${totalPages}`);
        }
        const startIndex = (page - 1) * itemsPerPage;
        const currentPageItems = products.slice(startIndex, startIndex + itemsPerPage);
        const productList = currentPageItems.map((item, i) => {
            return `╔════════════════════╗\n` +
                   `║  Produk: *${startIndex + i + 1}.* ${item.status_emoji} *${item.name}*\n` +
                   `║  Kategori: ${item.category}\n` +
                   `║  Tipe: ${item.type}\n` +
                   `║  Status: ${item.status === 'available' ? '✅ Available' : '❌ Tidak Tersedia'}\n` +
                   `║  Harga: ${item.price_formatted}\n` +
                   `╚════════════════════╝`;
        }).join('\n\n');
        const caption = `🛒 *DAFTAR PRODUK - ${category.toUpperCase()}*\n📄 *Halaman ${page}/${totalPages}*\n\n${productList}`;
        const navButtons = Array.from({ length: totalPages }, (_, i) => ({
            header: '🛒 Daftar Produk',
            title: `📄 Halaman ${i + 1}`,
            id: `.produk ${category} ${i + 1}`,
        }));
        const menuButton = {
            buttonId: 'action',
            buttonText: { displayText: '📦 PILIH HALAMAN' },
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: `📦 Produk Kategori ${category.toUpperCase()}`,
                    sections: [
                        {
                            title: `🛒 Pilih halaman produk`,
                            highlight_label: 'Halaman Tersedia',
                            rows: navButtons, 
                        }
                    ]
                }),
            },
        };
        await VPedia.sendMessage(m.chat, {
            document: { url: imgpedia },
            caption: caption,
            mimetype: 'application/zip',
            footer: 'WhatsApp Integration V-Pedia',
            buttons: [
                {
                    buttonId: '.deposit',
                    buttonText: { displayText: '💶 DEPOSIT' },
                    type: 1,
                },
                menuButton,
            ],
            headerType: 5,
            viewOnce: true,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                externalAdReply: {
                    title: wm,
                    body: wm,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    thumbnailUrl: imgpedia,
                    sourceUrl: saluran,
                    showAdAttribution: false,
                    containsAutoReply: true,
                    mentionedJid: [m.sender]
                },
                forwardedNewsletterMessageInfo: {
                    newsletterJid: idch,
                    newsletterName: wm,
                    serverMessageId: 143,
                },
                businessMessageForwardInfo: {
                    businessOwnerJid: VPedia.decodeJid(VPedia.user.id),
                }
            }
        });
    } catch (err) {
        console.error(err);
        m.reply('⚠️ Terjadi kesalahan saat mengambil produk.');
    }
}
break

case 'providers':
case 'provider': {
    try {
        const axios = require('axios');
        const url = `${BASE_URL}/h2h/providers?apikey=${API_KEY}`;
        const res = await axios.get(url);
        const data = res.data;

        if (!data.success) {
            return m.reply('❌ Gagal mengambil data provider.');
        }

        const providers = data.data;

        const rows = providers.map((prov) => ({
            header: '📡 Daftar Provider',
            title: `📌 ${prov}`,
            id: `.listproviders ${prov}`,
        }));

        const formattedList = providers.map((prov, i) => `🔹 *${i + 1}.* ${prov}`).join('\n');

        const menuButton = {
            buttonId: 'action',
            buttonText: { displayText: '📦 PILIH PROVIDER' },
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: '📡 Provider Produk Tersedia',
                    sections: [{
                        title: '📡 Silakan pilih provider',
                        highlight_label: 'Tersedia',
                        rows: rows
                    }]
                }),
            },
        };

        await VPedia.sendMessage(m.chat, {
            document: { url: imgpedia },
            caption: `📡 *LIST PROVIDER PRODUK*\n\n${formattedList}`,
            mimetype: 'application/zip',
            footer: wm,
            buttons: [
                {
                    buttonId: '.deposit',
                    buttonText: { displayText: '💶 DEPOSIT' },
                    type: 1,
                },
                menuButton
            ],
            headerType: 5,
            viewOnce: true,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                externalAdReply: {
                    title: wm,
                    body: 'V-PEDIA',
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    thumbnailUrl: imgpedia,
                    sourceUrl: saluran,
                    showAdAttribution: false,
                    containsAutoReply: true,
                    mentionedJid: [m.sender]
                },
                forwardedNewsletterMessageInfo: {
                    newsletterJid: idch,
                    newsletterName: wm,
                    serverMessageId: 143,
                },
                businessMessageForwardInfo: {
                    businessOwnerJid: VPedia.decodeJid(VPedia.user.id),
                }
            }
        });
    } catch (err) {
        console.error(err);
        m.reply('⚠️ Terjadi kesalahan saat mengambil provider.');
    }
}
break

case 'listproviders': {
    try {
        const axios = require('axios');
        const [providerRaw, pageRaw] = text.split(' ');
        const provider = providerRaw?.trim();
        const page = parseInt(pageRaw) || 1;

        if (!provider) {
            return m.reply('❌ Contoh penggunaan:\n.listprov TELKOMSEL\n.listprov TELKOMSEL 2');
        }

        const url = `${BASE_URL}/h2h/price-list?provider=${provider}&apikey=${API_KEY}`;
        const res = await axios.get(url);
        const data = res.data;

        if (!data.success || !Array.isArray(data.data)) {
            return m.reply('❌ Gagal mengambil data produk.');
        }

        const products = data.data;
        const itemsPerPage = 5;
        const totalPages = Math.ceil(products.length / itemsPerPage);

        if (page > totalPages || page < 1) {
            return m.reply(`❌ Halaman tidak ditemukan. Total halaman: ${totalPages}`);
        }

        const startIndex = (page - 1) * itemsPerPage;
        const currentPageItems = products.slice(startIndex, startIndex + itemsPerPage);

        const productList = currentPageItems.map((item, i) => {
            return `╔════════════════════╗\n` +
                   `║  Produk: *${startIndex + i + 1}.* ${item.status_emoji} *${item.name}*\n` +
                   `║  Kategori: ${item.category}\n` +
                   `║  Tipe: ${item.type}\n` +
                   `║  Status: ${item.status === 'available' ? '✅ Available' : '❌ Tidak Tersedia'}\n` +
                   `║  Harga: ${item.price_formatted}\n` +
                   `╚════════════════════╝`;
        }).join('\n\n');

        const caption = `🛒 *DAFTAR PRODUK - ${provider.toUpperCase()}*\n📄 *Halaman ${page}/${totalPages}*\n\n${productList}`;

        const navButtons = Array.from({ length: totalPages }, (_, i) => ({
            header: '🛒 Daftar Produk',
            title: `📄 Halaman ${i + 1}`,
            id: `.listprov ${provider} ${i + 1}`,
        }));

        const menuButton = {
            buttonId: 'action',
            buttonText: { displayText: '📦 PILIH HALAMAN' },
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: `📦 Produk Provider ${provider.toUpperCase()}`,
                    sections: [{
                        title: '🛒 Pilih halaman produk',
                        highlight_label: 'Halaman Tersedia',
                        rows: navButtons
                    }]
                }),
            },
        };

        await VPedia.sendMessage(m.chat, {
            document: { url: imgpedia },
            caption: caption,
            mimetype: 'application/zip',
            footer: 'WhatsApp Integration V-Pedia',
            buttons: [
                {
                    buttonId: '.deposit',
                    buttonText: { displayText: '💶 DEPOSIT' },
                    type: 1,
                },
                menuButton
            ],
            headerType: 5,
            viewOnce: true,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                externalAdReply: {
                    title: wm,
                    body: wm,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    thumbnailUrl: imgpedia,
                    sourceUrl: saluran,
                    showAdAttribution: false,
                    containsAutoReply: true,
                    mentionedJid: [m.sender]
                    },
                forwardedNewsletterMessageInfo: {
                    newsletterJid: idch,
                    newsletterName: wm,
                    serverMessageId: 143,
                },
                businessMessageForwardInfo: {
                    businessOwnerJid: VPedia.decodeJid(VPedia.user.id),
                }
            }
        });
    } catch (err) {
        console.error(err);
        m.reply('⚠️ Terjadi kesalahan saat mengambil produk.');
    }
}
break

case 'deposit': {
  try {
    if (!args[0]) return m.reply('❗️ Contoh penggunaan:\n.deposit 10000');

    const nominal = parseInt(args[0]);
    if (isNaN(nominal) || nominal < 500) return m.reply('❌ Minimal deposit Rp500');

    initializeUser(m.sender);
    const user = global.db.data.users[m.sender];

    const axios = require('axios');
    const res = await axios.get(`${BASE_URL}/h2h/deposit/create?nominal=${nominal}&apikey=${API_KEY}`);
    const json = res.data;

    if (!json.success) return m.reply('❌ Gagal membuat permintaan deposit');

    const data = json.data;
    const depositId = data.id;

    user.statusdepo = true;
    user.trxid = depositId;
    user.saldo = user.saldo || 0;
    if (typeof saveDatabase === 'function') saveDatabase();

    let qrMsg = await VPedia.sendMessage(m.chat, {
      image: { url: data.qr_image },
      caption: `*DEPOSIT DIBUAT*\n\n• Nominal: Rp${data.nominal}\n• Fee: Rp${data.fee}\n• Saldo Diterima: Rp${data.get_balance}\n• Reff ID: ${data.reff_id}\n• Status: ${data.status}\n\n⏳ Menunggu pembayaran...`
    }, { quoted: m });

    const cekStatusDeposit = async () => {
      try {
        const cek = await axios.get(`${BASE_URL}/h2h/deposit/status?trxid=${depositId}&apikey=${API_KEY}`);
        const status = cek.data;

        if (status.success && status.data.status === 'success') {
          if (qrMsg.key) await VPedia.sendMessage(m.chat, { delete: qrMsg.key });

          const saldoMasuk = parseInt(status.data.saldo_masuk);
          user.saldo += saldoMasuk;
          user.statusdepo = false;
          user.trxid = null;
          if (typeof saveDatabase === 'function') saveDatabase();

          await m.reply(`✅ *Deposit berhasil!*\nSaldo masuk: Rp${saldoMasuk}`);

        } else {
          setTimeout(cekStatusDeposit, 6000);
        }
      } catch (e) {
        console.log('[Cek Deposit]', e.message);
        setTimeout(cekStatusDeposit, 6000);
      }
    };

    cekStatusDeposit();

  } catch (e) {
    console.error(e);
    m.reply('⚠️ Terjadi kesalahan saat membuat deposit.');
  }
}
break

case 'order': {
    try {
        if (!args[0]) return m.reply('❗️ Contoh: .order DANA1,085216955233');

        let [code, target] = args[0].split(',');
        if (!code || !target) return m.reply('❌ Format salah! Contoh: .order DANA1,085216955233');

        const axios = require('axios');
        const user = global.db.data.users[m.sender];
        if (!user) return m.reply('❌ Kamu belum terdaftar di database.');

        const getPrice = await axios.get(`${BASE_URL}/h2h/price-list?apikey=${API_KEY}`);
        const produk = getPrice.data.data.find(x => x.code.toUpperCase() === code.toUpperCase());
        if (!produk) return m.reply('❌ Produk tidak ditemukan.');
        
        const harga = produk.final_price;
        if (user.saldo < harga) return m.reply(`❌ Saldo tidak cukup.\n💰 Saldo kamu: Rp${user.saldo}\n💸 Harga: Rp${harga}`);

        const orderURL = `${BASE_URL}/h2h/order/create?code=${code}&target=${target}&apikey=${API_KEY}`;
        const res = await axios.get(orderURL);
        const json = res.data;

        if (!json.success) return m.reply(`❌ Gagal order: ${json.message}`);

        const data = json.data;
        const sentMessage = await m.reply(`✅ *Transaksi Dikirim!*\n\n🛒 Produk: ${data.layanan}\n🎯 Target: ${data.target}\n💸 Harga: Rp${harga}\n🆔 Reff ID: ${data.reff_id}\n\n⏳ Menunggu status transaksi...`);

        const interval = setInterval(async () => {
            try {
                const statusURL = `${BASE_URL}/h2h/order/check?trxid=${data.id}&apikey=${API_KEY}`;
                const statusRes = await axios.get(statusURL);
                const statusData = statusRes.data;

                if (statusData.success) {
                    if (statusData.data.status === 'success') {
                        clearInterval(interval);
                        user.saldo -= harga;  
                        await VPedia.sendMessage(m.chat, { delete: sentMessage.key });
                        m.reply(`✅ *Transaksi BERHASIL!*\n\n🛒 Produk: ${data.layanan}\n🎯 Target: ${data.target}\n💸 Harga: Rp${harga}\n🆔 Reff ID: ${data.reff_id}`);
                    } else if (statusData.data.status === 'failed') {
                        clearInterval(interval);
                        await VPedia.sendMessage(m.chat, { delete: sentMessage.key });
                        m.reply(`❌ *Transaksi GAGAL!*\nSaldo tidak dipotong.`);
                    }
                }
            } catch (err) {
                console.log('🔁 Error cek status:', err.message);
            }
        }, 5000);

    } catch (e) {
        console.log(e);
        m.reply('⚠️ Terjadi kesalahan saat memproses order.');
    }
}
break


case 'saldo': {
  try {
    const user = global.db.data.users[m.sender];
    const saldo = user.saldo || 0;
    await m.reply(`💰 Saldo kamu saat ini: Rp${saldo}`);
  } catch (e) {
    console.error(e);
    m.reply('⚠️ Terjadi kesalahan saat mengecek saldo.');
  }
}
break

case 'cpanel': {
  if (!isPrem) return m.reply('❌ Fitur ini khusus untuk pengguna premium.');

  if (!text) return m.reply(`*Format salah!*\nPenggunaan: ${prefix + command} [ukuranGB] username,nomor\nContoh: ${prefix + command} 1gb mypanel,6281234567890`);

  const [sizeInput, rest] = text.trim().split(' ');
  if (!sizeInput || !rest) return m.reply(`*Format salah!*\nPenggunaan: ${prefix + command} [ukuranGB] username,nomor\nContoh: ${prefix + command} 1gb mypanel,6281234567890`);

  let sizeGB, memo, disk, cpu;

  switch (sizeInput.toLowerCase()) {
    case '1gb':
      sizeGB = 1;
      memo = 1025;
      disk = 1025;
      cpu = 50;
      break;
    case '2gb':
      sizeGB = 2;
      memo = 2048;
      disk = 2048;
      cpu = 100;
      break;
    case '3gb':
      sizeGB = 3;
      memo = 3072;
      disk = 3072;
      cpu = 150;
      break;
    case '4gb':
      sizeGB = 4;
      memo = 4096;
      disk = 4096;
      cpu = 200;
      break;
    case '5gb':
      sizeGB = 5;
      memo = 5120;
      disk = 5120;
      cpu = 250;
      break;
    case '6gb':
      sizeGB = 6;
      memo = 6144;
      disk = 6144;
      cpu = 300;
      break;
    case '7gb':
      sizeGB = 7;
      memo = 7168;
      disk = 7168;
      cpu = 350;
      break;
    case '8gb':
      sizeGB = 8;
      memo = 8192;
      disk = 8192;
      cpu = 400;
      break;
    case '9gb':
      sizeGB = 9;
      memo = 9216;
      disk = 9216;
      cpu = 450;
      break;
    case '10gb':
      sizeGB = 10;
      memo = 10240;
      disk = 10240;
      cpu = 500;
      break;
    case 'unli':
      sizeGB = 'unli';
      memo = 0;
      disk = 0;
      cpu = 0; 
      break;
    default:
      return m.reply(`❌ Ukuran panel tidak valid. Pilihan yang tersedia:
- 1gb
- 2gb
- 3gb
- 4gb
- 5gb
- 6gb
- 7gb
- 8gb
- 9gb
- 10gb
- unli

Contoh \`${prefix + command} 1gb username,nomor\`
`);
  }

  const parts = rest.split(',');
  if (parts.length < 2) return m.reply(`*Format salah!*\nPenggunaan: ${prefix + command} [ukuranGB] username,nomor\nContoh: ${prefix + command} 1gb mypanel,6281234567890`);

  const username = parts[0].trim();
  const nomorRaw = parts[1].trim();
  const tujuan = nomorRaw.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

  if (!tujuan) return m.reply('❌ Nomor tujuan tidak valid atau tidak disebutkan.');

  let egg = "15";
  let loc = "1";
  let panelImageUrl = "https://pomf2.lain.la/f/sni8rsa.png";
  let email = `${username}@gmail.com`;
  let password = `${username}${disk}`;

  try {
    const fUser = await axios.post(
      `${domain}/api/application/users`,
      {
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password.toString(),
      },
      {
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: "Bearer " + apikey,
        }
      }
    );

    const dataUser = fUser.data;
    if (dataUser.errors) return m.reply(`❌ *Error:* ${dataUser.errors[0].detail}`);

    const fEgg = await axios.get(
      `${domain}/api/application/nests/5/eggs/${egg}`,
      {
        headers: {
          Accept: "application/json",
          Authorization: "Bearer " + apikey,
        }
      }
    );

    const dataEgg = fEgg.data;
    const startup_cmd = dataEgg.attributes.startup;

    const fServer = await axios.post(
      `${domain}/api/application/servers`,
      {
        name: username,
        description: "Server dibuat oleh bot V-Pedia.",
        user: dataUser.attributes.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: startup_cmd,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start",
          JS_FILE: "index.js",
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 5,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      },
      {
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: "Bearer " + apikey,
        }
      }
    );

    const dataServer = fServer.data;
    if (dataServer.errors) return m.reply(`❌ *Error:* ${dataServer.errors[0].detail}`);

    const userInfo = dataUser.attributes;
    const serverInfo = dataServer.attributes;

    let teks = `*</> SERVERS CREATED </>*\n` +
      `*User Info* :\n` +
      `- ID : ${userInfo.id}\n` +
      `- Username : ${userInfo.username}\n` +
      `- Email : ${email}\n\n` +
      `*Server Info* :\n` +
      `- ID : ${serverInfo.id}\n` +
      `- Name : ${serverInfo.name}\n` +
      `- Memory : ${memo} MB\n` +
      `- Disk : ${disk} MB\n` +
      `- CPU : ${cpu}%\n`;

    let teks2 = `\`</> DATA PANEL ANDA </>\`\n` +
      `- Ukuran : ${sizeGB}GB\n` +
      `- Email : ${email}\n` +
      `- Username : ${userInfo.username}\n` +
      `- Password : ${password}\n` +
      `- Login : ${domain.replace("https://", "")}\n\n` +
      `\`</> INFO SERVER </>\`\n` +
      `- ID : ${serverInfo.id}\n` +
      `- Name : ${serverInfo.name}\n` +
      `- Memory : ${memo} MB\n` +
      `- Disk : ${disk} MB\n` +
      `- CPU : ${cpu}%\n`;

    await VPedia.sendMessage(
      m.chat,
      {
        document: { url: imgpedia },
        mimetype: "application/pdf",
        jpegThumbnail: { url: panelImageUrl },
        fileName: `Pterodactyl-Server-${username}.pdf`,
        caption: teks,
      },
      { quoted: m }
    );

    let msgii = generateWAMessageFromContent(
      tujuan,
      {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2
            },
            interactiveMessage: proto.Message.InteractiveMessage.create({
              contextInfo: { mentionedJid: [tujuan] },
              body: proto.Message.InteractiveMessage.Body.create({ text: teks2 }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons: [
                  {
                    "name": "cta_url",
                    "buttonParamsJson": `{\"display_text\":\"🌐 LINK LOGIN\",\"url\":\"${domain}\",\"merchant_url\":\"https://www.google.com\"}`
                  },
                  {
                    "name": "cta_copy",
                    "buttonParamsJson": JSON.stringify({
                      "display_text": "📋 COPY USERNAME",
                      "copy_code": `${username}`
                    })
                  },
                  {
                    "name": "cta_copy",
                    "buttonParamsJson": JSON.stringify({
                      "display_text": "🔑 COPY PASSWORD",
                      "copy_code": `${password}`
                    })
                  }
                ]
              })
            })
          }
        }
      },
      { userJid: tujuan, quoted: m }
    );
    await VPedia.relayMessage(tujuan, msgii.message, { messageId: msgii.key.id });
    m.reply("✅ *Server berhasil dibuat dan data sudah dikirim ke nomor tujuan.*");
  } catch (e) {
    console.error(e);
    m.reply('❌ Terjadi kesalahan saat membuat panel. Silakan coba lagi atau hubungi owner.');
  }
}
break


case 'buypanel': {
  if (!text) return m.reply(`*Format salah!*\nPenggunaan: ${prefix + command} [ukuranGB] [username]\nContoh: ${prefix + command} 1gb mypanel`);

  const args = text.trim().split(' ');
  if (args.length < 2) return m.reply(`*Format salah!*\nPenggunaan: ${prefix + command} [ukuranGB] [username]\nContoh: ${prefix + command} 1gb mypanel`);

  const sizeInput = args[0].toLowerCase();
  const username = args[1];
  
  let sizeGB, memo, disk, cpu, nominal;
  
  switch(sizeInput) {
    case '1gb':
      sizeGB = 1;
      memo = 1025;
      disk = 1025;
      cpu = 50;
      nominal = 500; 
      break;
    case '2gb':
      sizeGB = 2;
      memo = 2048;
      disk = 2048;
      cpu = 100;
      nominal = 2000;
      break;
    case '3gb':
      sizeGB = 3;
      memo = 3072;
      disk = 3072;
      cpu = 150;
      nominal = 3000;
      break;
    case '4gb':
      sizeGB = 4;
      memo = 4096;
      disk = 4096;
      cpu = 200;
      nominal = 4000;
      break;
    case '4gb':
      sizeGB = 4;
      memo = 4096;
      disk = 4096;
      cpu = 200;
      nominal = 4000;
      break;
    case '5gb':
      sizeGB = 5;
      memo = 5120;
      disk = 5120;
      cpu = 250;
      nominal = 5000;
      break;
    case '6gb':
      sizeGB = 6;
      memo = 6144;
      disk = 6144;
      cpu = 300;
      nominal = 6000;
      break;
    case '7gb':
      sizeGB = 7;
      memo = 7168;
      disk = 7168;
      cpu = 350;
      nominal = 7000;
      break;
    case '8gb':
      sizeGB = 8;
      memo = 8192;
      disk = 8192;
      cpu = 400;
      nominal = 8000;
      break;
    case '9gb':
      sizeGB = 9;
      memo = 9216;
      disk = 9216;
      cpu = 450;
      nominal = 9000;
      break;
    case '10gb':
      sizeGB = 10;
      memo = 10240;
      disk = 10240;
      cpu = 500;
      nominal = 10000;
      break;
    case 'unlimited':
      sizeGB = 'unlimited';
      memo = 0;
      disk = 0;
      cpu = 0;
      nominal = 15000; 
      break;
    default:
      return m.reply(`❌ Ukuran panel tidak valid. Pilihan yang tersedia:
- 1gb
- 2gb
- 3gb
- 4gb
- 5gb
- 6gb
- 7gb
- 8gb
- 9gb
- 10gb
- unli

Contoh \`${prefix + command} 1gb username\`
`);
  }

  initializeUser(m.sender);
  const user = global.db.data.users[m.sender];
  user.saldo = user.saldo || 0;

  if (user.statusdepo) return m.reply("⏳ Kamu masih punya deposit yang belum selesai, tunggu prosesnya.");

  try {
    const res = await axios.get(`${BASE_URL}/h2h/deposit/create?nominal=${nominal}&apikey=${API_KEY}`);
    const json = res.data;

    if (!json.success) return m.reply('❌ Gagal membuat permintaan deposit');

    const data = json.data;
    const depositId = data.id;

    user.statusdepo = true;
    user.trxid = depositId;
    

    const buttons = [
      { buttonId: `.batalbuypanel ${depositId}`, buttonText: { displayText: '❌ Batalkan Pembelian' }, type: 1 }
    ];

    let qrMsg = await VPedia.sendMessage(m.chat, {
      image: { url: data.qr_image },
      caption: `*PEMBAYARAN PANEL ${sizeGB}GB*\n\n• Ukuran: ${sizeGB}GB\n• RAM: ${memo}MB\n• Disk: ${disk}MB\n• CPU: ${cpu}%\n• Harga: Rp${nominal}\n• Fee: Rp${data.fee}\n• Total: Rp${data.nominal}\n• Reff ID: ${data.reff_id}\n• Status: ${data.status}\n\n⏳ Silakan scan QR untuk bayar.`,
      footer: 'Pembayaran akan otomatis dicek setiap 6 detik',
      buttons: buttons,
      headerType: 4
    }, { quoted: m });

    user.qrMessageKey = qrMsg.key; 
    if (typeof saveDatabase === 'function') saveDatabase();

    const cekStatusDeposit = async () => {
      if (!global.db.data.users[m.sender] || !global.db.data.users[m.sender].statusdepo || global.db.data.users[m.sender].trxid !== depositId) {
        return; 
      }
      try {
        const cek = await axios.get(`${BASE_URL}/h2h/deposit/status?trxid=${depositId}&apikey=${API_KEY}`);
        const status = cek.data;

        if (status.success && status.data.status === 'success') {
          const currentUser = global.db.data.users[m.sender];
          if (currentUser && currentUser.qrMessageKey) {
            await VPedia.sendMessage(m.chat, { delete: currentUser.qrMessageKey }).catch(e => console.error("Error deleting QR message on success: ", e));
            currentUser.qrMessageKey = null;
          }

          currentUser.statusdepo = false;
          currentUser.trxid = null;
          if (typeof saveDatabase === 'function') saveDatabase();

          await m.reply(`✅ *Pembayaran terkonfirmasi!*\nSedang membuat panel ${sizeGB}GB untuk username: *${username}*...`);

          let egg = "15";
          let loc = "1";
          let panelImageUrl = "https://pomf2.lain.la/f/sni8rsa.png";
          let email = `${username}@gmail.com`;
          let password = `${username}${disk}`;

          try {
            const fUser = await axios.post(
              `${domain}/api/application/users`,
              {
                email: email,
                username: username,
                first_name: username,
                last_name: username,
                language: "en",
                password: password.toString(),
              },
              {
                headers: {
                  Accept: "application/json",
                  "Content-Type": "application/json",
                  Authorization: "Bearer " + apikey,
                }
              }
            );
            const dataUser = fUser.data;
            if (dataUser.errors) return m.reply(`❌ *Error:* ${dataUser.errors[0].detail}`);

            const fEgg = await axios.get(
              `${domain}/api/application/nests/5/eggs/${egg}`,
              {
                headers: {
                  Accept: "application/json",
                  Authorization: "Bearer " + apikey,
                }
              }
            );
            const dataEgg = fEgg.data;
            const startup_cmd = dataEgg.attributes.startup;

            const fServer = await axios.post(
              `${domain}/api/application/servers`,
              {
                name: username,
                description: "Server dibuat oleh bot V-Pedia.",
                user: dataUser.attributes.id,
                egg: parseInt(egg),
                docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
                startup: startup_cmd,
                environment: {
                  INST: "npm",
                  USER_UPLOAD: "0",
                  AUTO_UPDATE: "0",
                  CMD_RUN: "npm start",
                  JS_FILE: "index.js",
                },
                limits: {
                  memory: memo,
                  swap: 0,
                  disk: disk,
                  io: 500,
                  cpu: cpu,
                },
                feature_limits: {
                  databases: 5,
                  backups: 5,
                  allocations: 5,
                },
                deploy: {
                  locations: [parseInt(loc)],
                  dedicated_ip: false,
                  port_range: [],
                },
              },
              {
                headers: {
                  Accept: "application/json",
                  "Content-Type": "application/json",
                  Authorization: "Bearer " + apikey,
                }
              }
            );
            const dataServer = fServer.data;
            if (dataServer.errors) return m.reply(`❌ *Error:* ${dataServer.errors[0].detail}`);

            const userInfo = dataUser.attributes;
            const serverInfo = dataServer.attributes;

            let teks2 = `\`</> DATA PANEL ANDA </>\`\n` +
              `- Ukuran : ${sizeGB}GB\n` +
              `- Email : ${email}\n` +
              `- Username : ${userInfo.username}\n` +
              `- Password : ${password}\n` +
              `- Login : ${domain.replace("https://", "")}\n\n` +
              `\`</> INFO SERVER </>\`\n` +
              `- ID : ${serverInfo.id}\n` +
              `- Name : ${serverInfo.name}\n` +
              `- Memory : ${memo} MB\n` +
              `- Disk : ${disk} MB\n` +
              `- CPU : ${cpu}%\n` +
              `- Harga : Rp${nominal}`;

            let msgii = generateWAMessageFromContent(
              m.chat,
              {
                viewOnceMessage: {
                  message: {
                    messageContextInfo: {
                      deviceListMetadata: {},
                      deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                      contextInfo: { mentionedJid: [m.sender] },
                      body: proto.Message.InteractiveMessage.Body.create({ text: teks2 }),
                      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                          {
                            "name": "cta_url",
                            "buttonParamsJson": `{\"display_text\":\"🌐 LINK LOGIN\",\"url\":\"${domain}\",\"merchant_url\":\"https://www.google.com\"}`
                          },
                          {
                            "name": "cta_copy",
                            "buttonParamsJson": JSON.stringify({
                              "display_text": "📋 COPY USERNAME",
                              "copy_code": `${username}`
                            })
                          },
                          {
                            "name": "cta_copy",
                            "buttonParamsJson": JSON.stringify({
                              "display_text": "🔑 COPY PASSWORD",
                              "copy_code": `${password}`
                            })
                          }
                        ]
                      })
                    })
                  }
                }
              },
              { userJid: m.sender, quoted: m }
            );

            await VPedia.relayMessage(m.sender, msgii.message, { messageId: msgii.key.id });
            m.reply("✅ *Server berhasil dibuat dan data sudah dikirim ke pengguna.*");

          } catch (err) {
            console.error(err);
            await m.reply('❌ Gagal membuat panel setelah pembayaran. Hubungi owner.');
          }

        } 
        else if (global.db.data.users[m.sender] && global.db.data.users[m.sender].statusdepo && global.db.data.users[m.sender].trxid === depositId) {
          setTimeout(cekStatusDeposit, 6000);
        }
      } catch (e) {
        console.log('[Cek Deposit]', e.message);
        if (global.db.data.users[m.sender] && global.db.data.users[m.sender].statusdepo && global.db.data.users[m.sender].trxid === depositId) {
          setTimeout(cekStatusDeposit, 6000);
        }
      }
    };

    cekStatusDeposit();

  } catch (e) {
    console.error(e);
    user.statusdepo = false;
    user.trxid = null;
    user.qrMessageKey = null;
    if (typeof saveDatabase === 'function') saveDatabase();
    m.reply('⚠️ Terjadi kesalahan saat memproses pembelian panel.');
  }
}
break

case 'batalbuypanel': {
  if (!text) return m.reply(`Format: ${prefix + command} [trxid]`);
  
  const trxidToCancel = text.trim();
  const user = global.db.data.users[m.sender];
  
  if (!user || !user.statusdepo || user.trxid !== trxidToCancel) {
    return m.reply('❌ Tidak ada transaksi aktif dengan ID tersebut atau transaksi milik orang lain.');
  }

  const storedQrKey = user.qrMessageKey;

  try {
    const res = await axios.get(`${BASE_URL}/h2h/deposit/cancel?trxid=${trxidToCancel}&apikey=${API_KEY}`);
    const json = res.data;

    if (json.success) {
      if (storedQrKey) {
        await VPedia.sendMessage(m.chat, { delete: storedQrKey }).catch(e => console.error("Error deleting QR message on cancel: ", e));
      }
      user.statusdepo = false;
      user.trxid = null;
      user.qrMessageKey = null;
      if (typeof saveDatabase === 'function') saveDatabase();
      m.reply(`✅ Deposit berhasil dibatalkan\nID: ${trxidToCancel}`);
    } else {
      m.reply(`❌ Gagal membatalkan deposit: ${json.message || 'Tidak ada detail error'}`);
    }
  } catch (e) {
    console.error(e);
    m.reply('⚠️ Terjadi kesalahan saat membatalkan deposit.');
  }
}
break

    //=====[ AKHIR FEATRUE CASE ]=====//
    }

    if (budy.startsWith('>') && isCreator) {
      try {
        let evaled = await eval(budy.slice(2));
        if (typeof evaled !== 'string') evaled = util.inspect(evaled);
        await m.reply(evaled);
      } catch (err) {
        m.reply(String(err));
      }
    }
    if (budy.startsWith('<') && isCreator) {
      let teks;
      try {
        teks = await eval(`(async () => { ${text ? "return" : ""} ${text} })()`);
      } catch (e) {
        teks = e;
      } finally {
        await m.reply(util.format(teks));
      }
    }
    if (budy.startsWith('$') && isCreator) {
      const cmd = budy.slice(1).trim();
      if (!cmd) return m.reply('❌ Perintah shell kosong!');
      const { exec } = require('child_process');
      exec(cmd, { maxBuffer: 1024 * 1024 }, (error, stdout, stderr) => {
        if (error) return m.reply(`❌ Error:\n${error.message}`);
        if (stderr) return m.reply(`⚠️ Stderr:\n${stderr}`);
        const output = stdout || '✅ Perintah dijalankan tanpa output.';
        const replyText = output.length > 4000 ? output.slice(0, 4000) + '\n...[truncated]' : output;
        m.reply('```bash\n' + replyText + '\n```');
      });
    }

  } catch (err) {
    console.log(chalk.red(util.format(err)));
  }
  let file = require.resolve(__filename);
  fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(chalk.red(`${__filename} updated!`));
    delete require.cache[file];
    require(file);
  });
};
