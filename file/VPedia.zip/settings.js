
/*

    #Rerezz Official 
    #Barmods Official 
*/


const fs = require('fs')

global.owner = ["6285216955233", "6285215527536"]
global.ownername = "CS V-PEDIA"
global.ownernumber = "6285216955233"
global.botname = "V-Pedia"
global.botnumber = "6285216955233"

global.imgpedia = "https://files.catbox.moe/oj984n.png"
global.saluran = "https://whatsapp.com/channel/0029Vat4lwpKLaHoS0MAwj3Z"
global.idch = "120363352182866347@newsletter"
global.wm = "V Pedia Official"

//=====[ API SETTINGS ]=====//
global.BASE_URL = "https://www.v-pedia.web.id"
global.API_KEY = "V-Pedia-of7ba79xg7ivieob"
//=====[ PANEL SETTINGS ]=====//
global.domain = "https://#"
global.apikey = "#"

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})